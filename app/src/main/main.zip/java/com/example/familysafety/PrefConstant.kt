package com.example.familysafety



object PrefConstants {

    const val IS_USER_LOGGED_IN = "isUserLoggedIn"
}