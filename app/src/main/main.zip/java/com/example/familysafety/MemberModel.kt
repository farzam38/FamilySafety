package com.example.familysafety

data class MemberModel(
    val name: String,
    val address: String,
    val time: String,
    val battery: String,
    val distance: String,
    val wifi: String,

)
